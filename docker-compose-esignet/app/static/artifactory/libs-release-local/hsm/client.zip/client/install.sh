#!/bin/bash
echo "Dummy hsm installation file executed."
